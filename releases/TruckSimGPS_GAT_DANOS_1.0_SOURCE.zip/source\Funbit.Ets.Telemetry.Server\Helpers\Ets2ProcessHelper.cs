﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace Funbit.Ets.Telemetry.Server.Helpers
{
    public static class Ets2ProcessHelper
    {
        static long _lastCheckTime;
        static bool _cachedRunningFlag;
        static int _lastProcessId;

        /// <summary>
        /// Returns last running game name: "ETS2", "ATS" or null if undefined.
        /// </summary>
        public static string LastRunningGameName { get; set; }

        /// <summary>
        /// Returns the installation path of the last detected running game, or null if not available.
        /// </summary>
        public static string LastRunningGamePath { get; set; }

        /// <summary>
        /// Returns the product version of the last detected running game's exe (e.g. "1.59.1"),
        /// or null if not available. Read from the file's version metadata, not from the SCS SDK
        /// (which only reports its own API schema version).
        /// </summary>
        public static string LastRunningGameProductVersion { get; set; }

        /// <summary>
        /// Checks whether ETS2 game process is running right now. The maximum check frequency is restricted to 1 second.
        /// </summary>
        /// <returns>True if ETS2 process is run, false otherwise.</returns>
        public static bool IsEts2Running
        {
            get
            {
                if (DateTime.Now - new DateTime(Interlocked.Read(ref _lastCheckTime)) > TimeSpan.FromSeconds(1))
                {
                    Interlocked.Exchange(ref _lastCheckTime, DateTime.Now.Ticks);
                    var processes = Process.GetProcesses();
                    foreach (Process process in processes)
                    {
                        try
                        {
                            // ProcessName only — MainWindowTitle is mutated by third-party
                            // overlays (VTLog) and localized game builds, both of which broke
                            // the previous StartsWith("Euro Truck Simulator 2") check.
                            bool running = process.ProcessName == "eurotrucks2" ||
                                           process.ProcessName == "amtrucks";
                            if (running)
                            {
                                _cachedRunningFlag = true;
                                LastRunningGameName = process.ProcessName == "eurotrucks2" ? "ETS2" : "ATS";

                                int currentPid = process.Id;

                                // Only extract path if this is a new process instance (optimization)
                                if (currentPid != _lastProcessId)
                                {
                                    // Try to get the game installation path
                                    try
                                    {
                                        string exePath = process.MainModule.FileName;
                                        string exeDir = Path.GetDirectoryName(exePath);

                                        // The exe is typically in bin\win_x64 or bin\win_x86, so we need to go up to the game root
                                        // Example: F:\SteamLibrary\steamapps\common\American Truck Simulator\bin\win_x64\amtrucks.exe
                                        // We want: F:\SteamLibrary\steamapps\common\American Truck Simulator

                                        string gameRoot = null;
                                        DirectoryInfo currentDir = new DirectoryInfo(exeDir);

                                        // Go up directories until we find one with base.scs and bin folder
                                        while (currentDir != null && currentDir.Parent != null)
                                        {
                                            string testPath = currentDir.FullName;
                                            string baseScsPath = Path.Combine(testPath, "base.scs");
                                            string binPath = Path.Combine(testPath, "bin");

                                            if (File.Exists(baseScsPath) && Directory.Exists(binPath))
                                            {
                                                gameRoot = testPath;
                                                break;
                                            }

                                            currentDir = currentDir.Parent;
                                        }

                                        LastRunningGamePath = gameRoot;
                                        LastRunningGameProductVersion = FileVersionInfo.GetVersionInfo(exePath).ProductVersion;
#if DEBUG
                                        Console.WriteLine($"PROCESS DEBUG: Exe path: '{exePath}'");
                                        Console.WriteLine($"PROCESS DEBUG: Game root: '{LastRunningGamePath}'");
                                        Console.WriteLine($"PROCESS DEBUG: Game product version: '{LastRunningGameProductVersion}'");
#endif
                                    }
                                    catch (Exception ex)
                                    {
#if DEBUG
                                        Console.WriteLine($"PROCESS DEBUG: Failed to get process path: {ex.Message}");
#endif
                                        LastRunningGamePath = null;
                                        LastRunningGameProductVersion = null;
                                    }

                                    _lastProcessId = currentPid;
                                }
                                // else: Same PID, use cached LastRunningGamePath

                                return _cachedRunningFlag;
                            }
                        }
                        // ReSharper disable once EmptyGeneralCatchClause
                        catch
                        {
                        }
                    }
                    _cachedRunningFlag = false;
                    _lastProcessId = 0; // Clear cache when no game running
                    LastRunningGameProductVersion = null;
                }
                return _cachedRunningFlag;
            }
        }
    }
}